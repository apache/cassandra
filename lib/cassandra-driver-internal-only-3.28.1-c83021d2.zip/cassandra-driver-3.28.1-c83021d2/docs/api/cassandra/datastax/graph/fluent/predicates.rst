:mod:`cassandra.datastax.graph.fluent.predicates`
=================================================

.. module:: cassandra.datastax.graph.fluent.predicates


.. autoclass:: Search
   :members:

.. autoclass:: CqlCollection
   :members:

.. autoclass:: Geo
   :members:
